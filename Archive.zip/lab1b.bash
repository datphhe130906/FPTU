
#!/bin/bash

read -p "Nhập vào độ cao của tam giác: " height

for ((i = 1; i <= height; i++))
do
    # In ra khoảng trắng phía trước
    for ((j = 1; j <= (height - i) * 4; j++))
    do
        echo -n " "
    done

    # In ra các số từ i xuống 1
    for ((k = i; k >= 1; k--))
    do
        echo -n "$k "
    done

    echo ""  # Xuống dòng
done
